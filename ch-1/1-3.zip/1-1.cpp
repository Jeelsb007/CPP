#include<stdio.h>
main(){
	int n;
	printf("enter the size of an array: ");
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++){
		printf("enter a[%d]: ",i);
		scanf("%d",&a[i]);
	
	}
	for(i=0;i<n;i++){
	
	printf("a[%d]:%d\n",i,a[i]);
}
	for(i=0;i<n;i++){
	if(a[i]%2==0){
		printf("%d\n",a[i]);
	}
	
}
 
}

