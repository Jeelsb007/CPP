#include<stdio.h>
main(){
	int i;
	for(i=2020;i<=3030;i++){
	if(i%4==0){
		printf("this is the leap year:%d\n",i);
	   } 
	}
	 
}
